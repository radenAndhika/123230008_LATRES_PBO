package controller;

import model.Transaksi;
import view.Transaksiview;

public class Transaksicontroller {
    private Transaksi model;
    private Transaksiview view;

    public Transaksicontroller(Transaksi model, Transaksiview view) {
        this.model = model;
        this.view = view;

        // Menambahkan event listener untuk tombol tambah transaksi
        this.view.setTambahButtonListener(e -> simpanTransaksi());
    }

    public void simpanTransaksi() {
        // Mengambil data dari View
        String namaPelanggan = view.getNamaPelanggan();
        String namaObat = view.getNamaObat();
        double hargaSatuan = view.getHargaSatuan();
        int jumlahBeli = view.getJumlahBeli();

        // Memperbarui model dengan data dari View
        model.setNamaPelanggan(namaPelanggan);
        model.setNamaObat(namaObat);
        model.setHargaSatuan(hargaSatuan);
        model.setJumlahBeli(jumlahBeli);

        // Menghitung total bayar
        double totalBayar = model.hitungTotal();

        // Menampilkan transaksi di View
        String transaksi = "Pelanggan: " + model.getNamaPelanggan() +
                "\nObat: " + model.getNamaObat() +
                "\nTotal Bayar: Rp " + totalBayar;
        view.tampilkanTransaksi(transaksi);
    }
}
