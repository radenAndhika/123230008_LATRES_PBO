package database;

import model.Transaksi;
import java.sql.*;

public class konekDB {
    private Connection connection;

    public konekDB() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/apotek", "root", "password");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void simpanTransaksi(Transaksi transaksi) {
        try {
            String query = "INSERT INTO transaksi (nama_pelanggan, nama_obat, harga_satuan, jumlah_beli, total_bayar) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, transaksi.getNamaPelanggan());
            stmt.setString(2, transaksi.getNamaObat());
            stmt.setDouble(3, transaksi.getHargaSatuan());
            stmt.setInt(4, transaksi.getJumlahBeli());
            stmt.setDouble(5, transaksi.hitungTotal());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
