package fixinshaallah;

import model.Transaksi;
import view.Transaksiview;
import controller.Transaksicontroller;

public class Fixinshaallah {
    public static void main(String[] args) {
        // Membuat objek model dan view
        Transaksi model = new Transaksi("", "", 0, 0); // Model kosong untuk diisi dengan input pengguna
        Transaksiview view = new Transaksiview();

        // Menghubungkan model dan view melalui controller
        Transaksicontroller controller = new Transaksicontroller(model, view);

        // Menampilkan tampilan view (aplikasi GUI)
        view.setVisible(true);  // Pastikan ini ada untuk menampilkan GUI
    }
}

