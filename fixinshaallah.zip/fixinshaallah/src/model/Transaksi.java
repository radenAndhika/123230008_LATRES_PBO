package model;

public class Transaksi {
    private String namaPelanggan;
    private String namaObat;
    private double hargaSatuan;
    private int jumlahBeli;
    private double totalHarga;
    private double diskon;
    private double totalBayar;

    // Constructor
    public Transaksi(String namaPelanggan, String namaObat, double hargaSatuan, int jumlahBeli) {
        this.namaPelanggan = namaPelanggan;
        this.namaObat = namaObat;
        this.hargaSatuan = hargaSatuan;
        this.jumlahBeli = jumlahBeli;
    }

    // Setter methods
    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public void setHargaSatuan(double hargaSatuan) {
        this.hargaSatuan = hargaSatuan;
    }

    public void setJumlahBeli(int jumlahBeli) {
        this.jumlahBeli = jumlahBeli;
    }

    // Method untuk menghitung total harga dan diskon
    public double hitungTotal() {
        totalHarga = hargaSatuan * jumlahBeli;
        if (jumlahBeli > 5) {
            diskon = totalHarga * 0.1; // Diskon 10%
        } else {
            diskon = 0;
        }
        totalBayar = totalHarga - diskon;
        return totalBayar;
    }

    // Getter methods
    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public double getHargaSatuan() {
        return hargaSatuan;
    }

    public int getJumlahBeli() {
        return jumlahBeli;
    }

    public double getTotalHarga() {
        return totalHarga;
    }

    public double getDiskon() {
        return diskon;
    }

    public double getTotalBayar() {
        return totalBayar;
    }
}
