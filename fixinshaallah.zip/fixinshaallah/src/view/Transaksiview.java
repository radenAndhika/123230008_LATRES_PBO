package view;

import javax.swing.*;
import java.awt.*;

public class Transaksiview extends JFrame {
    private JTextField namaPelangganField;
    private JTextField namaObatField;
    private JTextField hargaSatuanField;
    private JTextField jumlahBeliField;
    private JButton tambahButton;
    private JTextArea transaksiArea;

    public Transaksiview() {
        setTitle("Aplikasi Transaksi Penjualan Obat");
        setSize(400, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Untuk memusatkan jendela aplikasi

        // Membuat panel utama dengan GroupLayout
        JPanel panel = new JPanel();
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        
        // Membuat komponen input dan label
        JLabel labelNamaPelanggan = new JLabel("Nama Pelanggan:");
        JLabel labelNamaObat = new JLabel("Nama Obat:");
        JLabel labelHargaSatuan = new JLabel("Harga Satuan (Rp):");
        JLabel labelJumlahBeli = new JLabel("Jumlah Beli:");

        namaPelangganField = new JTextField(20);
        namaObatField = new JTextField(20);
        hargaSatuanField = new JTextField(10);
        jumlahBeliField = new JTextField(5);
        tambahButton = new JButton("Tambah Transaksi");

        // Area untuk menampilkan transaksi
        transaksiArea = new JTextArea(8, 30);
        transaksiArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(transaksiArea);
        
        // Menata komponen menggunakan GroupLayout
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(labelNamaPelanggan)
                    .addComponent(labelNamaObat)
                    .addComponent(labelHargaSatuan)
                    .addComponent(labelJumlahBeli))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(namaPelangganField)
                    .addComponent(namaObatField)
                    .addComponent(hargaSatuanField)
                    .addComponent(jumlahBeliField)
                    .addComponent(tambahButton)
                    .addComponent(scrollPane))
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNamaPelanggan)
                    .addComponent(namaPelangganField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNamaObat)
                    .addComponent(namaObatField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(labelHargaSatuan)
                    .addComponent(hargaSatuanField))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(labelJumlahBeli)
                    .addComponent(jumlahBeliField))
                .addComponent(tambahButton)
                .addComponent(scrollPane)
        );

        // Menambahkan panel ke frame
        add(panel);
    }

    // Getter methods untuk mendapatkan input dari pengguna
    public String getNamaPelanggan() {
        return namaPelangganField.getText();
    }

    public String getNamaObat() {
        return namaObatField.getText();
    }

    public double getHargaSatuan() {
        return Double.parseDouble(hargaSatuanField.getText());
    }

    public int getJumlahBeli() {
        return Integer.parseInt(jumlahBeliField.getText());
    }

    public void tampilkanTransaksi(String transaksi) {
        transaksiArea.append(transaksi + "\n");
    }

    public void tampilkanPesan(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public void setTambahButtonListener(java.awt.event.ActionListener listener) {
        tambahButton.addActionListener(listener);
    }
}
